<?php
include '../header.php';
include '../includes/dbh.inc.php';
$rid=$_GET['rid'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Ordering</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        html{
            scroll-behavior:smooth;
        }
        .navback{
            background-color:white;
            height:8vh;
            position:fixed;
            top:0%;
            width:100%;
        }
        .header{
            background-image: linear-gradient(0deg,rgb(200,191,243) 5%,white 90%);
            width: 100%;
            height: 35vh;
            margin-top:8%;
            border-radius:0px 0px 20px 20px;
        }
        .header img{
            float:right;
            margin-left:10%;
            width:30%;
        }
        .header p{
            font-size:50px;
            font-family:Segoe UI, Tahoma, Geneva, Verdana, sans-serif;
            font-weight:600;
            padding:30px;
            width:30%;
            margin:2% 0% 0% 18%;    
           overflow:hidden;
        }
        .main{
            position:sticky;
            top:8%;
            padding:5px;
            background:white;
            
        }
        .main p{
            font-size:30px;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }
        ul{
            list-style:none;
        }
        ul li{
            display:inline-block;
            padding:10px;
        }
        ul li a{
            border:1px solid gray;
            padding:15px;
            border-radius:20px;
            color:black;
            text-decoration:none;
        }
        .row1{
            display:grid;
            gap:2%;
            margin-top:10px;
            
            grid-template-columns:23% 23% 23% 23%;
        }
        .col1{
            
        }
        .col1 p{
            padding:2px;
        }
        .col1:hover{
            transform:scale(.97);
            transition:1s;
            cursor: pointer;
            box-shadow:5px 6px 10px black;
     
        }
       
        
    </style>

</head>
<body class="">
    <div class="navback">
    </div>
    <div class="">
        <div class="header d-flex justify-content-left">
            <img src="../img/download.webp" alt="" height="100%">
           <p class="text-center ">Order Food Online in Easy Way</p>
        </div>
        <div class="container">
            <div class="main">
            <p>Restaurants with online food delivery</p>
                <div class="flex-fill">
                <ul>
                    <li><a href=""><i class="fa-solid fa-filter"></i>Filter</a></li>
                    <li><a href="">Sort By</a></li>
                    <li><a href="">Fast Delivery</a></li>
                    <li><a href="">Rating 4.0</a></li>
                    <li><a href="">Offers</a></li>
                    <li><a href="">less than 100</a></li>
                </ul>
                </div>
            </div>
    <div class="row1">
        <?php
        $sql1="select * from items";
        $res=mysqli_query($conn,$sql1);
        while($data=mysqli_fetch_assoc($res))
        {
            echo "
            <div class=col1>
            <a href=order.php?rid=$rid&i_id=$data[i_id]>
            <img  class=rounded src=$data[image] width=100% height=200px>
            <p style=color:blue;font-size:20px;line-height:20px;>$data[item]</p>
            <p style=line-height:0px;>Delivery Time: $data[time] minutes</p>
            <p style=line-height:0px;color:green;font-size:20px;>&#8377;$data[cost]</p>
            <p style=line-height:0px;color:red;font-size:20px;>$data[stock]</p>
            </a>
        </div>
            ";
        }
        ?>
    
        </div>
    </div>
</body>
</html>