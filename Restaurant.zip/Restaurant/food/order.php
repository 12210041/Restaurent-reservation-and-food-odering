<?php
include '../header.php';
$rid = $_GET['rid'];
$i_id = $_GET['i_id'];
include '../includes/dbh.inc.php';
// echo "<pre>";
// print_r($_GET);
// echo "</pre>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>order</title>
    <style>
        .contain{
            position:fixed;
            top:10%;
            width:66%;
            left:17%;  
        }
        .hed{
            font-size:200%;
            text-decoration:underline;
        }
        img{
            float:right;
            width:30%;
            border-radius:30px;
        }
        p{
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            font-style:italic;
            font-size:20px;
        }
        input{
            width:50px;
            height:50px;
            padding:px;
            border:none;
            color:white;
            border-radius:50%;
            text-align:center;
            background:gray;
         
        }
        a{
            font-size:30px;
            padding:5px;
        }
        label{
            padding:5px;
            font-size:30px;
        }
        img:hover{
           
            margin-top:10%;
            transition:1s;
            transform:translateX(-10%);
            transform:scale(2);
        }
    </style>    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body class="">
    <div class="contain bg-light">
        <form method="post">
        <p class="d-flex justify-content-center hed">Process to order your select food</p>
        <?php
        $rs=0;
        $sql="select * from items where i_id=$i_id;";
        $res=mysqli_query($conn,$sql);
        while($data=mysqli_fetch_assoc($res))
        {
            echo "
            <img src=$data[image]>
            ";
            echo "
            <div class=col1>
            <p style=color:blue;font-size:40px;line-height:20px;>$data[item]</p>
            <p ><span style=color:blue> Ingeredients:</span>$data[Ingrediance]</p>
            <p ><span style=color:blue>Description: </span>$data[Description]</p>
            <p style=line-height:0px;>Delivery Time: $data[time] minutes</p>
            <p style=line-height:0px;color:green;font-size:40px;padding:10px;>&#8377;$data[cost]</p>
            <p style=line-height:0px;color:red;font-size:20px;>$data[stock]</p>
            
        </div>
            ";
            $rs=$data["cost"];
        }
        ?>
        <div class="d-flex justify-content-center">
        &#8377;<p id="cost" style="color:red;font-size:20px;"></p>
        <label>Quantity</label>
        <a onclick="decrease()"><i class="fa-solid fa-minus"></i></a>
        <input type="text" readonly id="quan" value="1">
        <a  onclick="increase()"><i class="fa-solid fa-circle-plus"></i></a>
        <input type="submit" name="final" value="order" class="btn btn-success" style="width:auto">
        </div>
        <?php
        $sql2="insert into foodorder(reserve_id,item_id,quantity) values($rid,$i_id);"
        ?>
        

    </div>
    <script>
        let fistp=<?php echo $rs;?>;
        function increase()
        {
            let x=document.getElementById('quan').value;
            let y=parseInt(x)+1;
            document.getElementById('quan').value=y;
            if(y>5){
                document.getElementById('quan').style.background="green";
            }
            document.getElementById('cost').innerHTML=fistp*y;
        }
        function decrease()
        {
            let x=document.getElementById('quan').value;
            let y=parseInt(x);
            if(y>0)
            {
                y=y-1;
            }
            document.getElementById('quan').value=y;
            if(y<5){
                document.getElementById('quan').style.background="gray";
            }
            document.getElementById('cost').innerHTML=fistp*y;
        }
        </script>
</body>
</html>