<?php
    include '../includes/dbh.inc.php';
    $id=$_GET['id'];
    $sql="delete from food_category where cid=$id";
    mysqli_query($conn,$sql);
    header('location:food_category.php');
?>