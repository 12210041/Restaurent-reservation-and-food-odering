<?php
include 'header.php';
include '../includes/dbh.inc.php';
require 'verifylogin.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <style>
        * Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: red; 
  border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #b30000; 
}
        .login{
            width:30%;
            position:fixed;
           border-radius:20px;
            top:15%;
            left:10%;
            box-shadow:5px 4px 10px black;
        }
        .show{
            width:50%;
            position:fixed;
            border-radius:20px;
            height:70vh;
            top:15%;
            right:7%;
            box-shadow:5px 4px 10px black;
            overflow:scroll;
        }
        .head,label,input{
            padding:10px;
            border-radius:20px;
            width:90%;
            text-align:center;
            margin:5%;
        }
        label,input{
           margin:0% 0% 0% 5%;
           text-align:left;
        }
        table,td,tr,th{
            border:1px solid black;
            padding:20px
        }
    </style>
</head>
<body>
    <div class="login">
        <div class="head bg-success">
            Add Category
        </div>
        <div>
            <form method="POST">
            <div class="alert alert-success" role="alert" style="display:none;">
                Category Added Successfully.
                </div>
                <div class="alert alert-danger" role="alert" style="display:none;">
                Category Added Successfully.
                </div>
                <label for="userid">Category</label>
                <input type="text" name="cat" id="cat">
                <input type="submit" id="add" name="add" style="margin:5%" class="btn btn-outline-success" value="add">
            </form>
        </div>
    </div>
    <?php 
    if(isset($_POST["add"]))
    { 
        $sql="INSERT into food_category values(null,'$_POST[cat]');";
        if(mysqli_query($conn,$sql))
        {
           
            ?><script>
                document.querySelector('.alert-success').style.display="block";
                document.querySelector('.alert-danger').style.display="none";
            </script><?php
        }else
        {
            ?><script>
            document.querySelector('.alert-success').style.display="none";
             document.querySelector('.alert-danger').style.display="block";
        </script><?php
        }
    }

   
    ?>
    <div class="show">
        <div class="head bg-success">
            Category
        </div>
        <div>     
            <table width="100%">
                <tr>
                    <th>Category id</th>
                    <th>Category Name</th>
                    <th>Total Item</th>
                    <th>Delete</th>
                    <th>Edit</th>
                   
                </tr>
                <?php
                $sql1="select * from food_category;";
                $res=mysqli_query($conn,$sql1);
                while($data=mysqli_fetch_assoc($res))
                {?>
                    <tr>
                    <th><?php echo $data["cid"]?></th>
                    <th><?php echo $data["category"]?></th>
                    <th>2</th>
                    <th><a href="foodcategory-delete.php?id=<?php echo $data['cid'];?>"><i class="fa-sharp fa-solid fa-trash"></i></a></th>
                    <th><a href="foodcategory-edit.php?id=<?php echo $data['cid'];?>"><i class="fa-sharp fa-solid fa-pen-to-square"></i></a></th>
                    
                </tr>
                <?php
                }
                ?>
            </table>
        </div>
    </div>
    
</body>
</html>