<?php
    include '../includes/dbh.inc.php';
    $id=$_GET['id'];
    $sql="delete from items where i_id=$id";
    mysqli_query($conn,$sql);
    header('location:add_item.php');
    ?>
    