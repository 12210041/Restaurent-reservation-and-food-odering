<?php
include 'header.php';
include '../includes/dbh.inc.php';
require 'verifylogin.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <style>
                ::-webkit-scrollbar {
            width: 20px;
            }

            /* Track */
            ::-webkit-scrollbar-track {
            box-shadow: inset 0 0 5px grey; 
            border-radius: 10px;
            }
            
            /* Handle */
            ::-webkit-scrollbar-thumb {
            background:lightblue; 
            border-radius: 10px;
            }

            /* Handle on hover */
            ::-webkit-scrollbar-thumb:hover {
            background: #b30000; 
            }
        .login{
            width:30%;
            position:fixed;
           border-radius:20px;
            top:15%;
            left:10%;
            box-shadow:5px 4px 10px black;
            overflow:scroll;
            height:70vh;
        }
        .show{
            width:50%;
            position:fixed;
            border-radius:20px;
            height:70vh;
            top:15%;
            right:7%;
            box-shadow:5px 4px 10px black;
            overflow:scroll;
        }
        .head,label,input,select{
            padding:10px;
            border-radius:20px;
            width:90%;
            text-align:center;
            margin:5%;
        }
        label,input{
           margin:0% 0% 1% 5%;
           text-align:left;
        }
        table,td,tr,th{
            border:1px solid black;
            padding:20px
        }
    </style>
</head>
<body>
    <div class="login">
        <div class="head bg-success">
            Add Category
        </div>
        <div>
            <form method="POST" enctype="multipart/form-data">
            <div class="alert alert-success" role="alert" style="display:none;">
                Category Added Successfully.
                </div>
                <div class="alert alert-danger" role="alert" style="display:none;">
                Category Added Successfully.
                </div>
                <label for="userid">Category</label>
                <select name="cat" id="cat">
                <option  value="select">Select</option>
                    <?php
                     $sql3="select * from food_category;";
                     $res1=mysqli_query($conn,$sql3);
                     while($data=mysqli_fetch_assoc($res1))
                     {
                        echo "<option value=$data[category]>$data[category]</option>";
                     }
                    ?>
                </select>
                <label for="userid">Select Image</label>
                <input type="file" name="image" id="image">
                <label for="userid">Item</label>
                <input type="text" name="item" id="item">
                <label for="userid">Cost</label>
                <input type="text" name="cost" id="cost">
                <label for="userid">Time Consuming</label>
                <input type="text" name="time" id="time">
                <label for="userid">Ingrediance</label>
                <input type="text" name="ing" id="ing">
                <label for="userid">Description</label>
                <input type="text" name="des" id="des">
                <input type="submit" name="additem" id="additem" class="btn btn-success" style="margin-top:2%;">
                <input type="reset" class="btn btn-success" style="margin-top:2%;">
            </form>
        </div>
    </div>
    <?php
       
        if(isset($_POST['additem']))
        {
            $target_img="";
            if(isset($_FILES['image']))
        {
            $tmpfile=$_FILES['image']['tmp_name'];
            $filename=$_FILES['image']['name'];
            if(move_uploaded_file($tmpfile,"../uploaded_image/".$filename));
            $target_img="../uploaded_image/".$filename;
        }
           
           
            $cat=$_POST['cat'];
            $item=$_POST['item'];
            $cost=$_POST['cost'];
            $time=$_POST['time'];
            $ing=$_POST['ing'];
            $des=$_POST['des'];
            $sql4="insert into items values(null,'$cat','$target_img','$item','$cost','$time','$ing','$des',null);";
            if(mysqli_query($conn,$sql4))
            {
                ?>
                <script>
                    document.querySelector('.alert-success').style.display="block";
                    document.querySelector('.alert-danger').style.display="none";
                    </script>

                <?php 
            }
            else
            {
                ?>
                <script>
                    document.querySelector('.alert-success').style.display="none";
                    document.querySelector('.alert-danger').style.display="block";
                    </script>

                <?php 
            }
        }
        ?>
   
    <div class="show">
        <div class="head bg-success">
            Category
        </div>
        <div>     
            <table width="100%">
                <tr>
                    <th>Category Name</th>
                    <th>Item Name</th>
                    <th>Item Image</th>
                    <th>Item Price</th>
                    <th>Time Consuming</th>
                    <th>Item Ingredients</th>
                    <th>Item Description</th>
                    <th>Item Stock</th>
                    <th>Delete</th>
                    <th>Edit</th>
                    
                </tr>
                <?php
               
                $sql5="select * from items;";
                $res4=mysqli_query($conn,$sql5);
                while($data=mysqli_fetch_assoc($res4))
                {   $imgsrc=$data["image"];
                    ?>
                    <tr>
                    <th><?php echo $data["category"]?></th>
                    <th><?php echo $data["item"]?></th>
                    <th> <img src=<?php echo $imgsrc ;?> width=100% class="rounded" height=100% >  </th>
                    <th><?php echo $data["cost"]?></th>
                    <th><?php echo $data["time"]?></th>
                    <th><?php echo $data["Ingrediance"]?></th>
                    <th><?php echo $data["Description"]?></th>
                    <th><?php echo $data["stock"]?></th>
                    
                    <th><a href="deleteitem.php?id=<?php echo $data['i_id'];?>"><i class="fa-sharp fa-solid fa-trash"></i></a></th>
                    <th><a href="edititem.php?id=<?php echo $data['i_id'];?>"><i class="fa-sharp fa-solid fa-pen-to-square"></i></a></th>
                   
                </tr>
                <?php
                }
                ?>
            </table>
        </div>
    </div>
    
</body>
</html>