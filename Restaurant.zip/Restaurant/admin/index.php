<?php
include '../includes/dbh.inc.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        .login{
            width:30%;
            position:fixed;
           border-radius:20px;
            top:15%;
            left:35%;
            box-shadow:5px 4px 10px black;
            background:white;
         
        }
        .head,label,input{
            padding:10px;
            border-radius:20px;
            width:90%;
            text-align:center;
            margin:5%;
        }
        label,input{
           margin:0% 0% 0% 5%;
           text-align:left;
        }
        body{
            background:url('../img/b.jpeg');
            background-size:cover;
          
        }
    </style>
</head>
<body>
    <div class="login">
        <div class="head bg-success">
            Admin Login
        </div>
        <div class="creditional">
            <form action="" onsubmit="return captaValid()" method="post">
                <label for="userid">Userid</label>
                <input type="text" name="userid" id="userid">
                <label for="pass">Password</label>
                <input type="password" name="pass" id="userid">
                <label for="userid" style="width:auto;margin-top:5%;color:red;font-size:30px;">Capta</label>
                <input type="text" name="capta" id="capta" style="width:25%;margin-top:5%;border:none;font-size:30px;background-image:url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5lT9TUrJRO_zykhxElkEDsXMKC6kjBC09dQ2mtLEDUSdpWzu88PE-0eCwR13_nop1Pg&usqp=CAU);padding:2px;" readonly>
                <input type="text" name="ecapta" id="ecapta" style="width:25%;margin-top:5%;">
                <div class="alert alert-danger" role="alert" style="display:none">
                    Capta Invalid
                    </div>
                <input type="submit" id="submit" name="submit" style="margin:5%" class="btn btn-outline-success" value="Login">
                <a href="../" style="margin:5%" class="btn btn-warning"><i class="fa-solid fa-house-chimney-crack"></i>Go to Home</a>
            </form>
        </div>
    </div>
    <?php
    if(isset($_POST['submit']))
    {
        $user=$_POST["userid"];
        $pass=$_POST["pass"];
        $count=0;
        $sql="select pass from admin where userid='$user';";
        $res=mysqli_query($conn,$sql);
        $count=mysqli_num_rows($res);
        if($count>0)
        {
            session_start();
            $_SESSION['userid']=$_POST['userid'];
            header("location:dashboard.php");
        }
    }
  
    ?>
    <script>
        
        let str="1234567890ABCDEFGHIJKLMNOPQRSTVWXYZqwertyuioplkjhgfdsazxcvbnm";
        let Capta="";
        for(let i=0;i<6;i++)
        {
            let index=Math.random() * ((str.length-1)-0) + 0;
            Capta+=str.charAt(index);
        }
        document.getElementById('capta').value=Capta;
        
        function captaValid()
        {
            let x=document.querySelector('#capta').value;
            let x1=document.querySelector('#ecapta').value;
            if(x==x1)
            {
                return true;
            }else
            {
                document.querySelector('.alert-danger').style.display="block";
                return false;
            }
        }
    </script>
</body>
</html>