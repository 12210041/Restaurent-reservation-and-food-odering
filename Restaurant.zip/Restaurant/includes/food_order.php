<?php

if(isset($_SESSION['user_id'])){
    
    require 'includes/dbh.inc.php';
    
}
include "../header.php";
?>
<style>
    .box{
        top:0%;
       
        position:fixed;
        height:100vh;
        width:100%;
       border-radius:20px;
    }
    .bg-ligh{
        background-image:url(https://media.istockphoto.com/id/1018141890/photo/two-empty-wine-glasses-sitting-in-a-restaurant-on-a-warm-sunny-afternoon.jpg?s=612x612&w=0&k=20&c=OccJv1oKWSTDqJ6Irw7iW1NEbL0muU2ylqP3EOhOyEg=);
        background-size:cover;

    }
    .heading{
        padding:10px;
        background:lightblue;
        font-size:30px;
        color:green;
        position: relative;
        top:8%;
    }
</style>

<body class="bg-ligh">
    <div class="box bg-light">
    <div class="d-flex justify-content-center heading">Food Ordering</div>
    <div class="">
    </div>
    </div>
</body>